<?php

class UserEntity {
	//String
	public $userCode;
	
	//String
	public $entityCode;
}

?>