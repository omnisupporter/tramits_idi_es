<?php

class UserSearch {
	//String
	public $searchTerm;
	
	//String
	public $entityCode;
}

?>
