<?php

class StampPosition {
	//Long
	public $page;
	
	//Double
	public $x;
	
	//Double
	public $y;
	
	//Long
	public $height;
	
	//Long
	public $width;
}

?>