<?php

class UserCmis {
	//String
    public $pathbase;
	
	//String
    public $user;
	
	//String
	public $password;
	
	//String
	public $folderId;
}

?>