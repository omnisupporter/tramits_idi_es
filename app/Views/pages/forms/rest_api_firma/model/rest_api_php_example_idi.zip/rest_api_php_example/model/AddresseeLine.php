<?php

class AddresseeLine {
	//Array of AddresseeGroup
	public $addresseeGroups;
}

?>