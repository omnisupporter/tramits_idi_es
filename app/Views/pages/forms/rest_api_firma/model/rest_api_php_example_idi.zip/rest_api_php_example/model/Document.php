<?php

class Document {
	//String
	public $filename;
	
	//String
	public $base64;
	
	//String
	public $url;
	
	//Array of byte
	public $data;
	
	//String
	public $csv;
	
	//String
	public $verificationUrl;
	
	//Template
	public $template;
}

?>