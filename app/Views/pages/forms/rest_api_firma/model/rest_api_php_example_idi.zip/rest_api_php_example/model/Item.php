<?php

class Item {
	//String
	public $key;
	
	//String
	public $value;
}

?>