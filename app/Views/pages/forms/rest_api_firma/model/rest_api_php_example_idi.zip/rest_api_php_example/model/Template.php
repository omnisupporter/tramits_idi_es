<?php

class Template {
	//String
	public $code;
	
	//Array of Item
	public $vars;
}

?>