<?php

class Job {
	//String
	public $name;
	
	//String
	public $publicAccessId;
}

?>