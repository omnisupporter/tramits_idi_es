<?php

class UserEntityEmail {
	//String
    public $email;
	
	//String
    public $entityCode;
	
	//Boolean
	public $isDefault;
	
	//Array of String
	public $jobs;
	
	//Array of String
	public $groups;
}

?>