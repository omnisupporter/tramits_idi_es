<?php

class AddresseeGroup {
	//Boolean
	public $isOrGroup = false;
	
	//Array of AddresseeUserEntity
	public $userEntities;
}

?>