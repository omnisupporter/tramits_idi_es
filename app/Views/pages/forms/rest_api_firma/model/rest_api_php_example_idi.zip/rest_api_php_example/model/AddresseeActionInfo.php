<?php

class AddresseeActionInfo {
	//String
	public $userCode;
	
	//Date
	public $date;
	
	//String
	public $rejectType;
	
	//String
	public $rejectReason;
	
	//Array of Job
	public $jobs;
}

?>